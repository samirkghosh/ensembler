<?php 
require_once("dbconnect.php");  
require_once("ReportSupport.php");
require_once("function.php");
?>
<html>
<head>
	<title>Agent Disposition Report</title>
</head>
<body>

<?php
include_once("header.php");
include_once("reports.php");
extract($_REQUEST);
$start_date=setDateFormat($start_date);
$end_date=setDateFormat($end_date,2);

function smart_wordwrap($string, $width = 75, $break = "\n") {
	// split on problem words over the line length
	$pattern = sprintf('/([^ ]{%d,})/', $width);
	$output = '';
	$words = preg_split($pattern, $string, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);

	foreach ($words as $word) {
		if (false !== strpos($word, ' ')) {
			// normal behaviour, rebuild the string
			$output .= $word;
		} else {
			// work out how many characters would be on the current line
			$wrapped = explode($break, wordwrap($output, $width, $break));
			$count = $width - (strlen(end($wrapped)) % $width);

			// fill the current line and add a break
			$output .= substr($word, 0, $count) . $break;

			// wrap any remaining characters from the problem word
			$output .= wordwrap(substr($word, $count), $width, $break, true);
		}
	}

	// wrap the final output
	return wordwrap($output, $width, $break);
}


?>
  <div class="full">

	<input name="download" type="hidden" value="yes">

		<div class="alert alert-light" role="alert" style="margin-bottom: 0px">
			<a href="admin.php" style="text-decoration: none">Home</a> / <span class="heading">Agent Disposition Report</span>
		</div>


	<div class="container-fluid">
		<form action="" method="post" name="admin">

			<table class="table">
				<tbody>
					<tr>
						<td>Start Time </td>
						<td>
					        <input class="input_control date_class" name="start_date"   type="text" value="<?=date("d-m-Y H:i:s", strtotime($start_date))?>" required>
					   </td>
						<td>End Time </td>
						<td>
							<input class="input_control date_class" name="end_date"   type="text" value="<?=date("d-m-Y H:i:s", strtotime($end_date))?>" required>
						</td>
						<td>Select Campaign </td>
						<td>
							<?php
						$whr_condtion_campaign=get_assignedCampaign_Drop();

						//$queryCamp="select campaign_id from autodial_campaigns where active='Y' $whr_condtion_campaign";
						$queryCamp="select campaign_id from autodial_campaigns where active='Y' ";
						$query200New=mysqli_query($link,$queryCamp);

						?>
						 <select name="camp_id" required="" class="input_control" required>
						<option value="">--Select--</option>
						<?php 
						
						while ($query200Row = mysqli_fetch_assoc($query200New)) { 
							$camp_id=$_REQUEST['camp_id'];
							if ($query200Row['campaign_id']=="$camp_id") { 
								$selected="selected";
							}else{
								$selected="";									
							}
							?>
							<option <?=$selected?> value="<?=$query200Row['campaign_id'] ?>"><?=$query200Row['campaign_id'] ?></option>
						<? }
						?>
						</select>
						</td>
						<td>Dispostion </td>
						<td>
							<select name="subdispostion" class="input_control">
						<option value="">Select Dispostion</option>
						<?php
						$querydisp=mysqli_query($link,"SELECT * FROM tbl_disposition WHERE I_Status = 1");
						while ($query = mysqli_fetch_assoc($querydisp)) { 
							$sub_dispostion1=$_REQUEST['subdispostion'];

							if ($query['V_DISPO']==$sub_dispostion1) { 
								$selected="selected";
							}else{
								$selected="";									
							}
							?>
							<option <?=$selected?> value="<?=$query['V_DISPO'] ?>"><?=$query['V_DISPO']?></option>
						<? }
						?>
						</select>
						</td>
						<td>Agent </td>
						<td>
							<?php
								$where_cond_user=get_assignedUser_Drop();
								//$query_user="select user from autodial_users $where_cond_user ";
								$query_user="select user from autodial_users ";
								$query200New=mysqli_query($link,$query_user);
						
							?>
						</td>
						<td>
							<select name="user" class="input_control">
						<option value="">Select Agent</option>
						<?php 
							while ($query200Row = mysqli_fetch_assoc($query200New)) { 
								$user=$_REQUEST['user'];
								if ($query200Row['user']=="$user") { 
									$selected="selected";
								}else{
									$selected="";									
								}
							?>
							<option <?=$selected?> value="<?=$query200Row['user'] ?>"><?=$query200Row['user'] ?></option>
							<!-- <option <?=$selected?> value="<?=$query200Row['user'] ?>"><?=$query200Row['user']."(".getUserFullnameById($query200Row['user']).")" ?></option> -->
						<? }
						?>
						</select>
						</td>
						<td>
					<input name="submit" type="submit" value="Submit" class="btn btn-danger btn-sm">
				<?php if(isset($_REQUEST['submit'])){?>
					<!-- <input name="Download" onClick="downloads();" type="button" value="Download" class="btn btn-warning btn-sm" style="color: #fff"> -->
				<? }?>
		     <input name="action" type="hidden" value=""> 
						</td>
					</tr>
				</tbody>
			</table>

		</form>

	</div>
	<!-- End of container-fluid -->

		 <?php
		$user_detils=get_loginUserDetail($_SESSION['PHP_AUTH_USER'],$_SESSION['PHP_AUTH_PW']);
		$userCampign=$user_detils['user_camp'];
		$userLevel=$user_detils['user_level'];
		$vDepartment=$user_detils['v_department'];
		$campaignlist=get_commasep_campaigns($userCampign);
		if($userLevel!=9)
		{
			
			$where_condtion_agent=get_assignedUser_Drop();
			$query_agent="select user from autodial_users $where_condtion_agent ";
		}


		if($camp_id==''){
			if($userLevel!=9) $campCond=" and list_agent_log.campaign_id IN ($campaignlist)";	
		}else{
			$campCond=" and list_agent_log.campaign_id='$camp_id'";	
		}


		if($user==''){
			if($userLevel!=9) 
			{
				$userCond=" and list_agent_log.user  IN ($query_agent) ";
			}else{
				$userCond=" ";
			}
		}elseif($user!=""){
			$userCond=" and list_agent_log.user ='$user'";	
		}

		if($subdispostion=="")
		{
			$subCond="";
		}else{
			$subCond=" and (list_agent_log.status='$subdispostion'   OR list.status='$subdispostion' ) 	 ";
			
			
		}

		if($customer_search!=''){
			$customerCond=" AND (list.first_name like '$customer_search%' OR list.last_name like '$customer_search%'  )";
		}else{
			$customerCond=" ";	
		}

		//   $query="SELECT list_agent_log.dispo_sec,list.agent,list_agent_log.user,list_agent_log.hold_sec,list.list_id,list.lead_id,list.comments,list_agent_log.remarks,list.first_name,list.address3,list.alt_phone,list.vendor_lead_code,list.email,list.list_id,list_agent_log.filename,list.entry_date,list_agent_log.campaign_id,list.modify_date,list_agent_log.event_time,list_agent_log.sentiment,list_agent_log.status, list_agent_log.talk_sec,list.phone_number,list.called_count ,list.last_name,list.postal_code,list.industry,list.city  FROM autodial_list as list inner join autodial_agent_log as list_agent_log on list.lead_id=list_agent_log.lead_id where list.first_name!='' and list_agent_log.event_time between '$start_date' and '$end_date'  $campCond $userCond $subCond $customerCond   order by list_agent_log.agent_log_id desc";


		  $query="SELECT list_agent_log.dispo_sec,list.agent,list_agent_log.user,list_agent_log.hold_sec,list.list_id,list.lead_id,list.comments,list_agent_log.remarks,list.first_name,list.address3,list.alt_phone,list.vendor_lead_code,list.email,list.list_id,list_agent_log.filename,list.entry_date,list_agent_log.campaign_id,list.modify_date,list_agent_log.event_time,list_agent_log.sentiment,list_agent_log.status, list_agent_log.talk_sec,list.phone_number,list.called_count ,list.last_name,list.postal_code,list.industry,list.city  FROM autodial_list as list inner join autodial_agent_log as list_agent_log on list.lead_id=list_agent_log.lead_id where list_agent_log.event_time between '$start_date' and '$end_date'  $campCond $userCond $subCond $customerCond   order by list_agent_log.agent_log_id desc";

		//   echo $query;

	?>
                                    
        
		<div class="container-fluid">		
			<div class="table-responsive">
				   <div class="title_name" style="display: none;"></div> 
        <div class="report_name" style="display: none;"><?=date('dmY')?> </div> 
       <div class="download_label" style="display: none;">Agent Disposition Report From <?=date('d-m-Y',strtotime($start_date))?> To <?=date('d-m-Y',strtotime($end_date))?></div>
				<table class="table  table-hover table-bordered example">
					<thead>
						<tr>
							<th>SNo</th>
							<!-- <th>UploadDate</th> -->
							<th>CallerId</th>
							<th>AgentName</th>
							<th>CallerName</th>
							<!-- <th>Disposition</th> -->
							<th>Disposition</th>
							<th>Remark</th>
							<th>Talktime</th>
							<!-- <th>Ringtime</th> -->
							<th>Holdtime</th>
							<th>Wraptime</th>
							<th>AlternateNo</th>
							<!-- <th>UpdateDate</th> -->
							<!--<th>CallingDate</th>-->
							<th>EntryDate</th>
							<th>Address</th>
							<!-- <th>ListId</th> -->
							<th>Type</th> 
							<!-- <th>Sentiment</th> -->
	                      </tr>		
	                  </thead>
					
					<tbody>	
						<?php

											//not contact clause creation start
							$NotContactClause="select V_DISPO from tbl_disposition where I_Type=0";
							$NotContactClause=mysqli_query($link,$NotContactClause);
							$NotContactClauseString="";
							while ($NotContactClauseRow = mysqli_fetch_assoc($NotContactClause)) {
								$NotContactClauseString.="'".$NotContactClauseRow['V_DISPO']."',";
							}
							$NotContactClauseString=rtrim($NotContactClauseString,',');
							$NotContactClauseString=explode(",", $NotContactClauseString);
							//not contact clause creation end
							//contact clause creation start
							$ContactClause="select V_DISPO from tbl_disposition where I_Type=1";
							$ContactClause=mysqli_query($link,$ContactClause);
							$ContactClauseString="";
							while ($ContactClauseRow = mysqli_fetch_assoc($ContactClause)) {
								$ContactClauseString.="'".$ContactClauseRow['V_DISPO']."',";
							}
							$ContactClauseString=rtrim($ContactClauseString,',');
							$ContactClauseString=explode(",", $ContactClauseString);
							//contact clause creation end

						    // code for pagination starts
						    $leadPagePagination=20;
						    $pageUrl="AgentDispositionReport2.php";
					        $rec_limit = $leadPagePagination;
					        $query1 = mysqli_query($link,$query);
					        $rec_count = mysqli_num_rows($query1);
					        $stopper = intval($rec_count/10);
					        if( isset($_GET['page'] ) ) {
					        $page = $_GET['page'] + 1;
					        $offset = $rec_limit * $page ;
					        }else {
					        $page = 0;
					        $offset = 0;
					        }
					        $left_rec = $rec_count - ($page * $rec_limit);
					        // $query .= " LIMIT $offset, $rec_limit";
					        $query=mysqli_query($link,$query);
					        $no=$offset;
					        $count=0;
						 
							if (mysqli_num_rows($query)>0 && isset($_REQUEST['camp_id'])) {
								$totalcalltaken="";
								$Uniquetotalcalltaken="";
								$totalCount="";
								$totalCount2="";
								$s = 1;
								while ($row=mysqli_fetch_assoc($query)) {
									//print_r($row);die();
									$showdate=explode(" ", $row['entry_date']);
									// added for ansduration starts
									$query1="select ans_duration from autodial_agent_log where filename='".$row['filename']."'";
									$query1=mysqli_query($link,$query1)or die(mysqli_error($link)."error2");
									$query1Row=mysqli_fetch_assoc($query1);
									// added for ansduration ends

									$query2="select list_name from autodial_lists where list_id=".$row['list_id'];
									$query2=mysqli_query($link,$query2)or die(mysqli_error($link)."error3");
									$query2Row=mysqli_fetch_assoc($query2);
									// get Customer More Detail start
									$getIdfromAutoDialCutomerInfo="select pulp_cust_id from autodial_customer_info where vendor_lead_code='".$row['vendor_lead_code']."'";
									$getIdfromAutoDialCutomerInfoData=mysqli_query($link,$getIdfromAutoDialCutomerInfo);
									$getIdfromAutoDialCutomerInfoRow=mysqli_fetch_assoc($getIdfromAutoDialCutomerInfoData);
								
									// $query2Agent="select full_name,user from autodial_users where user='".$row['agent']."'";
									// $query2AgentData=mysqli_query($link,$query2Agent)or die(mysqli_error()$link.">66");
									// $query2AgentRow=mysqli_fetch_assoc($query2AgentData);
									// get Agent FullName ends

									?>
							
								<tr>								
								    <td><?=$s++;?></td>
								     <!-- <td><?=date("d-m-Y ", strtotime($showdate[0]))?></td> -->
								     
	                                <td><?=$row['phone_number']?></td>
	                                <!-- <td><?=$query2AgentRow['user']?></td> -->
	                                <td><?=$row['user']?></td>
									<td><?=$row['first_name']?></td>
									<!-- <td><?=(in_array("'".$row['status']."'", $NotContactClauseString) ? "Not Connected" : "Connected")?></td>  -->
									<td>
									<? if($row['status']=="CB"){
										echo "Call Back";
									}else{
										if ($row['status']=="") {
											$queryGetEscapeRemark=mysqli_query($link,"select location from recording_log where lead_id=".$row['lead_id'])or die(mysqli_error($link)."343>");
											$queryGetEscapeRemarkData=mysqli_fetch_assoc($queryGetEscapeRemark);
											echo $queryGetEscapeRemarkData['location'];
										}else{
											echo $row['status'];
										}
									}								
									?>
									</td>
									<td><?= smart_wordwrap($row['remarks'], 20) . "\n"; ?>
								</td> 
	                                <td><?=getSecondsToHourMinSec($query1Row['ans_duration'])?></td>
									<td><?=getSecondsToHourMinSec($row['hold_sec'])?></td>
									<!-- <td><?=getSecondsToHourMinSec($row['talk_sec'])?></td> -->
									<td><?=getSecondsToHourMinSec($row['dispo_sec'])?></td>
								   
	                                <td><?=$row['alt_phone']?></td>
									<!-- <td><?=date("d-m-Y H:i:s", strtotime($row['modify_date']))?></td> -->
	                                <!-- <td><?=$row['campaign_id']?></td> -->
	                                <!-- <td><?=$row['lead_id']?></td> -->
	                                <td><?=date("d-m-Y H:i:s", strtotime($row['event_time']))?></td>
									
									<!-- <td><?=date("d-m-Y H:i:s", strtotime($row['entry_date']))?></td> -->
									 <td><?=$row['address3']?></td>

									<!-- <td><?=$row['list_id']?></td> -->
									<td><?= $row['list_id']=="1000" ? "IN" : "OUT" ?></td> 
									<!-- <td><?=$row['sentiment']?></td> -->
								</tr>
										
									 
							<? } } // Close While Loop and if loop ?>
						
					</tbody>
				</table>
			</div>
		</div>
	</div>	
<!-- End of div.full -->

<!-- footer-->
<?php include_once("footer.php")?>
<!-- End of footer -->


<!-- code for calendar start -->

<script src="./jquery.js"></script> 

<script language="javascript">
	function downloads()
	{
		var start_date=document.admin.start_date.value;
		var end_date=document.admin.end_date.value;
		var camp_id=document.admin.camp_id.value;
		var user=document.admin.user.value;
		var subdispostion=document.admin.subdispostion.value;
		//var customer_search=document.admin.customer_search.value;
		window.location.href="DownloadAgent_Disposition_Report.php?start_date="+start_date+"&end_date="+end_date+"&camp_id="+camp_id+"&user="+user+"&subdispostion="+subdispostion+"";
	}

</script>
<script language="javascript">
/***********************************************
* Local Time script- © Dynamic Drive (http://www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit http://www.dynamicdrive.com/ for this script and 100s more.
***********************************************/

	var currentDate = new Date(),
	day = currentDate.getDate(),
	month = currentDate.getMonth() + 1,
	year = currentDate.getFullYear();
	
	
	var currentTime = new Date(),
	hours = currentTime.getHours(),
	minutes = currentTime.getMinutes();
	
	if (minutes < 10) {
	minutes = "0" + minutes;
	}
	
	var currentTime = new Date(),
	hours = currentTime.getHours(),
	minutes = currentTime.getMinutes();
	
	if (minutes < 10) {
	minutes = "0" + minutes;
	}
	
	var suffix = "AM";
	if (hours >= 12) {
	suffix = "PM";
	hours = hours - 12;
	}
	if (hours == 0) {
	hours = 12;
	}
	
	
</script>
<!-- code for calendar end -->
<script language="JavaScript" src="calendar1.js"></script> 
<script src="./jquery.datetimepicker.js"></script> 
<script>
		$('.date_class').datetimepicker({
			format : 'd-m-Y H:i:s',
			formatTime:'H:i',
			formatDate:'d-m-Y'

		});
	</script>
<!-- End -->

<!-- Datatable by farhan:03-02-2021 -->
<!--nprogress-->
<script src="dist/js/nprogress.js"></script>
<!--file dropify-->
<script src="dist/js/dropify.min.js"></script>
<script type="text/javascript" src="dist/datatables/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="dist/datatables/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="dist/datatables/js/jszip.min.js"></script>
<script type="text/javascript" src="dist/datatables/js/pdfmake.min.js"></script>
<script type="text/javascript" src="dist/datatables/js/vfs_fonts.js"></script>
<script type="text/javascript" src="dist/datatables/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="dist/datatables/js/buttons.print.min.js"></script>
<script type="text/javascript" src="dist/datatables/js/buttons.colVis.min.js" ></script>
<script type="text/javascript" src="dist/datatables/js/ss.custom.js" ></script>
<!-- End -->


</body>
</html>
