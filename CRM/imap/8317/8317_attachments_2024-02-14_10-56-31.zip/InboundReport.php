<? 
   require("dbconnect.php");
   require_once("ReportSupport.php");
   $PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];
   $PHP_AUTH_PW=$_SERVER['PHP_AUTH_PW'];
   $PHP_SELF=$_SERVER['PHP_SELF'];
   

function getTimeInFormated($seconds)
{
	$hours = floor($seconds / 3600);
	$mins = floor($seconds / 60 % 60);
	$secs = floor($seconds % 60);
	return sprintf('%02d:%02d:%02d', $hours, $mins, $secs);
}
   

function getSentiment($id)
{
   global $link;
   $db = 'ensembler';

   $query = "SELECT sentiment FROM $db.tbl_sentiment WHERE id = '$id' ";
   $res = mysqli_query($link,$query);
   $fetch = mysqli_fetch_assoc($res);
   return $fetch['sentiment'];
}
   
   ###################Pagination By Mitra ###########################
   
   
   if(isset($_REQUEST['page'])) $page=$_REQUEST['page']+1; else $page=1;
   	
   	$numofrecord=100;
   	$start=($_REQUEST['page']) ? ($_REQUEST['page']*$numofrecord) : 0;
   
   	//print_r($_POST);
   
   ############################################################# 
   	$stmtpermissions="SELECT user_level from autodial_users where user='$PHP_AUTH_USER';";
   	$rsltpermissions=mysqli_query($link,$stmtpermissions);
   	$rowperm=mysqli_fetch_row($rsltpermissions);
   	$user_perm=$rowperm[0];
   
   	$stmt_permissions="SELECT download_inbound from tbl_user_rights where user='$user_perm' ;";
   	$rslt_permissions=mysqli_query($link,$stmt_permissions);
   	$row_perm=mysqli_fetch_row($rslt_permissions);
   	$download_inbound_perm=$row_perm[0];
   
   
   
   
   
   	$PHP_AUTH_USER = preg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
   	$PHP_AUTH_PW = preg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);
   
   
   
   
   	$stmt="SELECT count(*) from autodial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW' and user_level > 6";	
   	$rslt=mysqli_query($link,$stmt);
   	$row=mysqli_fetch_row($rslt);
   	$auth=$row[0];
   
   	  if( (strlen($PHP_AUTH_USER)<2) or (strlen($PHP_AUTH_PW)<2) or (!$auth)){
   		    Header("WWW-Authenticate: Basic realm=\"Universus\"");
   		    Header("HTTP/1.0 401 Unauthorized");
   		    echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";
   		    exit;
   	   }
   	 else{
   		header ("Content-type: text/html; charset=utf-8");
   	     }
   
   
   	$curr_year = date("Y");
   	$curr_mon_str = date("M");$curr_mon = date("m");
   	$curr_date = date("d");
   	$curr_hour=date("H");
   	$curr_min=date("i");
   	$curr_sec=date("s");
   
   	$current_date = date("d-m-Y");	
   	$DOCroot = "$WeBServeRRooT/TCM3/ploticus";
   
   ?>
<HTML>
   <HEAD>
      <title>Universus ADMIN : Inbound Report</title>
      <link rel="stylesheet" type="text/css" href="./jquery.datetimepicker.css"/>
   </HEAD>
   <BODY>
      <?php 
         include("header.php");
         include("reports.php");?>
      <?php
         extract($_REQUEST);
         $start_date=setDateFormat($start_date);
         $end_date=setDateFormat($end_date,2);
         ?>
      <!--  Form START here  -->
      <div class="alert alert-light" role="alert">
         <a href="admin.php" style="text-decoration: none">Home</a> / <span class="heading">Inbound Detailed Report</span>
      </div>
      <div class="container-fluid">
         <form method=POST name=admin >
            <input type=hidden name=download value="yes">
            <table class="table">
               <tbody>
                  <tr>
                     <td>Start Time </td>
                     <td>
                        <input class="input_control date_class" name="start_date"   type="text" value="<?=date("d-m-Y H:i:s", strtotime($start_date))?>" required>
                     </td>
                     <td>End Time </td>
                     <td>
                        <input class="input_control date_class" name="end_date"   type="text" value="<?=date("d-m-Y H:i:s", strtotime($end_date))?>" required>
                     </td>
                     <td>Agent </td>
                     <td>
                        <SELECT name="user" class="input_control" style="width:163px">
                           <option value="ALL" selected>ALL</option>
                           <? $stmt="select (user) from autodial_users;";
                              $rslt=mysqli_query($link,$stmt);
                              $campaigns_to_print = mysqli_num_rows($rslt);
                              $o=0;
                              
                              if($user){ ?>
                           <option value="<?=$user?>" selected><?=$user?></option>
                           <?	}
                              while ($campaigns_to_print > $o){
                              	$row=mysqli_fetch_row($rslt);
                              	$groups[$o] =$row[0]; ?>
                           <option value="<?=$groups[$o]?>"><?=$groups[$o]?></option>
                           <?	$o++; } ?>
                        </SELECT>
                     </td>
                     <td> &nbsp;</td>
                  </tr>
                  <tr>
                     <td>DID </td>
                     <td>
                        <SELECT NAME="did" class="input_control" style="width:163px">
                           <option value="ALL" selected>ALL</option>
                           <?	$stmt="select did_name from autodial_closer_log where did_name<>'' group by did_name;";
                              $rslt=mysqli_query($link,$stmt);
                              $campaigns_to_print = mysqli_num_rows($rslt);
                              $i=0;
                              if($did){ ?>
                           <option value="<?=$did?>" selected><?=$did?></option>
                           <?}
                              while ($i < $campaigns_to_print)
                              {
                              	$row=mysqli_fetch_row($rslt);
                              	$groups[$i] =$row[0];
                              	$i++;
                              }
                              $o=0;
                              while ($campaigns_to_print > $o)
                              {
                              	if ($groups[$o] == $group) { ?>
                           <option selected value="<?=$groups[$o]?>">$<?=$groups[$o]?></option>
                           <?	} 
                              else {?>
                           <option value="<?=$groups[$o]?>"><?=$groups[$o]?></option>
                           <?}
                              $o++;
                              }?>
                        </SELECT>
                     </td>
                     <td>Queue Name </td>
                     <td>
                        <SELECT name="queue" class="input_control" style="width:163px">
                           <option value="ALL" selected>ALL</option>
                           <? $stmt="select campaign_id from autodial_closer_log where campaign_id<>'' group by campaign_id;";
                              $rslt=mysqli_query($link,$stmt);
                              $campaigns_to_print = mysqli_num_rows($rslt);
                              $i=0;
                              if($queue){ ?>
                           <option value="<?=$queue?>" selected><?=$queue?></option>
                           <? }
                              while ($i < $campaigns_to_print)
                              {
                              	$row=mysqli_fetch_row($rslt);
                              	$groups[$i] =$row[0];
                              	$i++;
                              }
                                $o=0;
                              while ($campaigns_to_print > $o)
                              {
                              	if ($groups[$o] == $group) { ?>
                           <option selected value="<?=$groups[$o]?>"><?=$groups[$o]?></option>
                           <?}
                              else { ?>
                           <option value="<?=$groups[$o]?>"><?=$groups[$o]?></option>
                           <?}
                              $o++;
                              } ?>
                        </SELECT>
                     </td>
                     <td>Status </td>
                     <td>
                        <?
                           if($status=='DONE')
                           {
                           	$check_done='selected';
                           }else{
                           	$check_done='';
                           }
                           
                           if($status=='INCALL')
                           {
                           	$check_INCALL='selected';
                           }else{
                           	$check_INCALL='';
                           } ?>
                        <SELECT NAME="status" class="input_control" style="width:163px">
                           <option value="ALL" selected>ALL</option>
                           <option value=INCALL <?=$check_INCALL?> >INCALL</option>
                           <option value=DONE <?=$check_done?> >DONE</option>
                        </SELECT>
                     </td>
                     <!-- <td colspan="3" >&nbsp;</td> -->
                  </tr>
                  <tr>
                     <td>Sentiment </td>
                     <td>
                        <?php
                             $db = 'ensembler';
                             $query = "select id,sentiment from $db.tbl_sentiment where status=1";
                             $res_sen = mysqli_query($link, $query); 
                             ?>
										<select class="input_control" name="sentiment" id="sentiment" style="width:163px">
                                 <option value="0">Select Sentiment</option>
                                 <? while ($row_sen = mysqli_fetch_array($res_sen)) { ?>
                                    <option value="<?= $row_sen['id'] ?>" <? if ($row_sen['id'] == $sentiment) {
                                       echo "selected";
                                    } ?>>
										<?= strtolower($row_sen['sentiment']) ?>
                           </option>
                           <? } ?>
                        </select>
                     </td>
                     <td><input type="submit" name="Submit" value="Submit" class="btn btn-sm btn-danger"></td>
                  </tr>
               </tbody>
            </table>
            <!-- <div class="row">
               <div class="col-sm-12">
               	<center>
               	<div class="mt-4">
               <input type="submit" name="Submit" value="Submit" class="btn btn-sm btn-danger">
               <input type='button' name='Download' value='Download' onClick='downloads();' class="btn btn-sm btn-warning" style="color: #fff;">
               </div>
               </center>
               </div>
               
               </div> -->
            <!-- End of row -->
         </form>
      </div>
      <!-- End of container-fluid --> 
      <div class="container-fluid">
         <div class="table-responsive">
            <div class="title_name" style="display: none;"></div>
            <div class="report_name" style="display: none;"><?=date('dmY')?> </div>
            <div class="download_label" style="display: none;">Inbound detailed Report From <?=date('d-m-Y',strtotime($start_date))?> To <?=date('d-m-Y',strtotime($end_date))?></div>
            <table class="table table-hover table-bordered example" >
               <thead>
                  <tr>
                     <th> SNo</b></th>
                     <th >Agent</b></th>
                     <th >DID Name</b></th>
                     <th >Queue Name</b></th>
                     <th >Call Date</b></th>
                     <th >Status</b></th>
                     <th >Disposition</b></th>
                     <th >Phone Number</b></th>
                     <th >Talk Time</b></th>
                     <th >Wrap Time</b></th>
                     <!-- <th >Ring Time</b></th> -->
                     <th >Hold Time</b></th>
                     <th >Call Handling Time</b></th>
                     <th >In Queue</b></th>
                     <th >Hangup By</b></th>
                     <th >Sentiment</b></th>
                     <th >Rec</b></th>
                  </tr>
               </thead>
               <tbody>
                  <?
                     //$cond_call_type=" and call_type='IN' and drop_status IS NULL ";
                     if(isset($_POST['submit']))
                     {
                     	
                     	$user		= $_GET['user'];	if(!$user)	{$user	= $_POST['user'];}
                     	$status		= $_GET['status'];	if(!$status)	{$status	= $_POST['status'];}
                     
                     	$b_time=$hhs . "-" . $mins . "-" . $secs;
                     	$e_time=$hhe . "-" . $mine . "-" . $sece;
                     
                     }
                     
                     if($user != ""){ 
                     	$check=$_POST['download'];if(!$check){$check=$_GET['download'];}
                     
                     	?>
                  <?
                     if($_POST['start_date'])	
                     {
                        if(!empty($sentiment))
                        {
                           $sentimentCond ="and v.sentiment = '$sentiment'";
                        }

                     	if($status=='DONE' || $status=='INCALL')
                     	{
                     		$stmt="select v.closecallid,v.lead_id,v.list_id,v.campaign_id,v.call_date,v.length_in_sec,
                     		v.status,v.phone_number,v.queue_seconds,v.did_name,v.user,r.length_in_sec as length , r.filename ,
                     		 r.location , r.callid,v.sentiment  from autodial_closer_log v ,recording_log r
                     		 where v.call_date >= '$start_date' and v.call_date <= '$end_date' 
                     		 and r.filename=v.filename $sentimentCond $cond_call_type ";
                     	}
                     	else
                     	{
                     
                     
                     		$stmt="select v.closecallid,v.lead_id,v.list_id,v.campaign_id,v.call_date,v.length_in_sec,
                     		v.status,v.phone_number,v.queue_seconds,v.did_name,v.user,r.length_in_sec as length , r.filename , 
                     		r.location, r.callid,v.sentiment  from autodial_closer_log v , recording_log r
                     		 where v.call_date >= '$start_date' and v.call_date <= '$end_date' 
                     		 and r.filename=v.filename $sentimentCond $cond_call_type ";
                     
                     	}
                     
                     
                     	if($status=='ALL'){ 
                     	 	//$stmt .=" and v.status like '%%' "; 
                     	}else{
                     	 	$stmt .=" and v.status = '$status' ";
                     	}
                     
                     	if($did=="ALL"){
                     		//$stmt .=" and v.did_name like '%%' ";
                     	}else{
                     		$stmt .=" and v.did_name = '$did' ";
                     	}
                     
                     	if($queue=="ALL"){
                     		//$stmt .=" and v.campaign_id like '%%' ";
                     	}
                     	else{
                     		$stmt .=" and v.campaign_id = '$queue' ";
                     	}
                     
                     	if($user=='ALL'){ 
                     		//$stmt .=" and v.user like '%%' "; /
                     	}
                     	else{ 
                     		$stmt .=" and v.user='$user' "; 
                     	}
                     
                     	$stmt .=" limit $start,$numofrecord ";
                     
                     	//echo $stmt;
                     	$rslt=mysqli_query($link,$stmt);
                         
                            $statuses_to_print = mysqli_num_rows($rslt);
                            
                           
                        ?>
                  <?
                     /********************************* Start by mitra8302 for zip recording******************************************************** */
                      // if number of row will greater than 0 then we remove previous zip folder from root folder and make a new folder for new fetched record
                     /********************************* Start by mitra8302 for zip recording******************************************************** */
                     
                     	// echo "<center><B><a href=\"/universus/Inboundrecord.zip\">click here</a> to download .zip file of all recordings files of above shown</B></center>";
                     if($statuses_to_print>0){ ?>
                  <!-- <center><B><a href="/universus/Inboundrecord.zip\">click here</a> to download .zip file of all recordings files of above shown</B></center> -->
                  <?	
                     //echo shell_exec("whoami");
                     //echo "11";
                         	shell_exec('rm -r /var/www/html/universus/Inboundrecord/');
                     shell_exec("rm /var/www/html/universus/Inboundrecord.zip");
                     //echo "1";
                     mkdir("/var/www/html/universus/Inboundrecord", 0777);
                     //echo "2";
                     
                     if($check == "yes"){ ?>
                  <form name="fone" action="<?=$PHP_SELF?>" method="POST">
                     <input type="hidden"  name="b_date" value="<?=$begin_date?>">
                     <input type="hidden"  name="e_date" value="<?=$end_date?>">
                     <input type="hidden"  name="b_time" value="<?=$b_time?>">
                     <input type="hidden"  name="e_time" value="<?=$e_time?>">
                     <input type="hidden"  name="user" value="<?=$user?>">
                     <input type="hidden"  name="campaign" value="<?=$campaignid?>">
                     <input type="hidden"  name="did" value="<?=$did?>">
                     <input type="hidden"  name="queue" value="<?=$queue?>">
                     <input type="hidden"  name="status" value="<?=$status?>">	
                  </form>
                  <?} ?>
                  <?	
                     if(!empty($sentiment))
                     {
                        $sentimentCond ="and v.sentiment = '$sentiment'";
                     }
                     
                                       
                     if($status=='DONE' || $status=='INCALL'){
                     
                     	$stmt="select v.closecallid,v.lead_id,v.list_id,v.campaign_id,v.call_date,v.length_in_sec,
                     	v.status,v.phone_number,v.queue_seconds,v.did_name,v.user,r.length_in_sec as length , r.filename ,
                     	 r.location , r.callid,v.sentiment  from autodial_closer_log v ,recording_log r
                     	 where v.call_date >= '$start_date' and v.call_date <= '$end_date' and r.filename=v.filename $sentimentCond $cond_call_type ";
                     }
                     else
                     {
                     
                     
                     $stmt="select v.closecallid,v.lead_id,v.list_id,v.campaign_id,v.call_date,v.length_in_sec,
                     	v.status,v.phone_number,v.queue_seconds,v.did_name,v.user,r.length_in_sec as length , r.filename , 
                     	r.location, r.callid,v.sentiment  from autodial_closer_log v , recording_log r
                     	 where v.call_date >= '$start_date' and v.call_date <= '$end_date' and r.filename=v.filename $sentimentCond $cond_call_type ";
                     
                     }


                      if($status=='ALL'){ 
                      	//$stmt .=" and v.status like '%%' "; 
                      }else{
                      	$stmt .="and v.status = '$status'";
                      }
                     
                     if($did=="ALL")
                     {
                     //$stmt .="and v.did_name like '%%' ";
                      }else{
                     $stmt .="and v.did_name = '$did' ";
                        }
                     
                     if($queue=="ALL")
                     {
                     //$stmt .="and v.campaign_id like '%%' ";
                     }else{
                     $stmt .="and v.campaign_id = '$queue' ";
                        }
                     
                     if($user=='ALL')
                     {
                        // $stmt .=" and v.user like '%%' "; 
                     }else{ 
                     	$stmt .=" and v.user='$user' "; 
                     }
                     //print_r($_REQUEST);echo $stmt;
                     $rsltt=mysqli_query($link,$stmt);
                           $numms = mysqli_num_rows($rsltt);
                           $breakpoint=floor($numms/$numofrecord);
                     ?>
                  <?
                     }	// $statuses_to_print heree 
                     $o1=0;
                     $no=0;
                     array_map('unlink', glob("Inboundrecord/*"));
                     while ($statuses_to_print > $o1) 
                     {
                     	$no++;
                     	$row=mysqli_fetch_row($rslt);
                     	if (preg_match("/^1$|3$|5$|7$|9$/", $o))
                     		{$bgcolor='class="rowOdd"';} 
                     	else
                     		{$bgcolor='class="rowEven"';}
                     
                     	$tupple=mysqli_fetch_array(mysqli_query($link,"SELECT event FROM `queue_log` where event IN ('COMPLETEAGENT','COMPLETECALLER') and callid='".$row[14]."' and callid!='';"));
                     
                     	if($tupple['event']=='COMPLETEAGENT') $calleragent="AGENT"; if($tupple['event']=='COMPLETECALLER') $calleragent="CALLER";
                     
                     		$tupple_dispo=mysqli_fetch_array(mysqli_query($link,"SELECT dispo_sec FROM `autodial_agent_log` where callid='".$row[14]."' and callid!='';"));  
                     		//$filename =	"../calls/".$row[12].".wav";
                     		//$count                         =          $count+1;
                     		//$sno                           =          $count; ?>
                  <tr <?=$bgcolor?>>
                     <td><?=$no?></td>
                     <td><?=$row[10]?></td>
                     <td><?=$row[9]?></td>
                     <td><?=$row[3]?></td>
                     <td><?=date('d-m-Y h:i:s',strtotime($row[4]))?></td>
                     <td><?=$row[6]?></td>
                     <td><?=$row[13]?></td>
                     <td><?=$row[7]?></td>
                     <td><?=getTimeInFormated($row[11])?></td>
                     <!-- <td><?=getTalktime($row[12])?></td>  -->
                     <td><?=getTimeInFormated($tupple_dispo['dispo_sec'])?></td>
                     <!-- <td><?=getTimeInFormated(0)?></td> -->
                     <td><?=getTimeInFormated(0)?></td>
                     <td><?=getTimeInFormated($row[11]+$tupple_dispo['dispo_sec'])?></td>
                     <td><?=getTimeInFormated(number_format($row[8]))?></td>
                     <td><?=$calleragent?></td>
                     <td><?=getSentiment($row[15])?></td>
                     <td>
                        <?php 
                           if(!empty($row[12])){ ?>
                        <a download="" href="<?=SmartFileName($row['12'])?>"><img src="images/playsound.png" border="0" width="16"></a>
                        <!--<a target='blank' href='<?=SmartFileName($row[12])?>'><img src='images/playsound.png' border='0' width='16'></a>-->
                        <?php } ?>	
                     </td>
                  </tr>
                  <?	 
                     $folder=getFileFolder($row[12]);
                     $sf="/var/www/html/calls/".$folder.$row[12].".WAV";
                     $df="Inboundrecord/";
                     shell_exec("cp -r $sf $df");
                     $o1++;
                     }
                     ?>
               </tbody>
            </table>
         </div>
      </div>
      <?	
         }	// start post close here
         
         
         
         	shell_exec("rm Inboundrecord.zip");
         	shell_exec("zip -r Inboundrecord.zip Inboundrecord/");
         }		// User if  close here 
         /************************* End by mitra 8302 **************************************************/
         
         function detail($val,$bd,$ed,$ai,$ci)
         {
         require("dbconnect.php");
         
         if($ai=="ALL" && $ci=="ALL")
         {$stmt="SELECT lead_id,entry_date,status,user,vendor_lead_code,phone_number,first_name,comments  from autodial_list where entry_date >= '$bd' and entry_date <= '$ed' and list_id=999 and status='$val'";}
         else if($ai!="ALL" && $ci=="ALL")
         {$stmt="SELECT lead_id,entry_date,status,user,vendor_lead_code,phone_number,first_name,comments  from autodial_list where entry_date >= '$bd' and entry_date <= '$ed' and user='$ai' and list_id=999 and status='$val'";}
         else if($ai=="ALL" && $ci!="ALL")
         {$stmt="SELECT lead_id,entry_date,status,user,vendor_lead_code,phone_number,first_name,comments  from autodial_list where entry_date >= '$bd' and entry_date <= '$ed' and  vendor_lead_code='$ci' and list_id=999 and status='$val'";}
         else if($ai!="ALL" && $ci!="ALL")
         {$stmt="SELECT lead_id,entry_date,status,user,vendor_lead_code,phone_number,first_name,comments  from autodial_list where entry_date >= '$bd' and entry_date <= '$ed' and user='$ai' and vendor_lead_code='$ci' and  list_id=999 and status='$val';";}
         //echo $stmt;	
         $rslt=mysqli_query($link,$stmt);
         $statuses_to_print = mysqli_num_rows($rslt);
         if($statuses_to_print>0){ ?>
      <!-- echo "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"; -->
      <table>
         <tr>
            <th>
               <b>
                  <center>Details </u></center>
               </b>
            </th>
            <br>
            <!-- <center> -->
            <table class="tableview example">
               <tr>
                  <th ><B>Lead ID</b></th>
                  <th ><B>Call Date</b></th>
                  <th ><B>Status</b></th>
                  <th ><B>Agent Id</b></th>
                  <th ><B>Campaign ID</b></th>
                  <th ><B>Phone Number</b></th>
                  <th ><B>Name(Caller)</b></th>
                  <th ><B>Comments</b></th>
               </tr>
               <!-- </center> -->
               <? }
                  $o1=0;
                  while ($statuses_to_print > $o1) 
                  {
                  	$row=mysqli_fetch_row($rslt);
                  	if (preg_match("/^1$|3$|5$|7$|9$/", $o))
                  		{$bgcolor='class="rowOdd"';} 
                  	else
                  		{$bgcolor='class="rowEven"';}
                  	?>
               <tr <?=$bgcolor?>>
                  <td><?=$row[0]?></td>
                  <td><?=$row[1]?></td>
                  <td><?=$row[2]?></td>
                  <td><?=$row[3]?></td>
                  <td><?=$row[4]?></td>
                  <td><?=$row[5]?></td>
                  <td><?=$row[6]?></td>
                  <td><?=$row[7]?></td>
               </tr>
               <?	$o1++; 
                  } // close while  ?>
            </table>
            <?
               }	// function close
               
               
               
               
               
                	
               
               	if (isset($_GET['action'])){
               		// Retrieve the GET parameters and executes the function
               		$funcName	 = $_GET['action'];
               		$vars	  = $_GET['vars'];
               		$begin_date=$_GET['begin_date'];
               		$end_date=$_GET['end_date'];
               		$user=$_GET['user'];
               		$campaignid=$_GET['campaignid'];
               		$status=$_GET['status'];
               		$funcName($vars,$begin_date,$end_date,$user,$campaignid); 
               	} 
               	else if (isset($_POST['action'])){
               	  	// Retrieve the POST parameters and executes the function
               	  	$funcName	 = $_POST['action'];
               		$vars	  = $_POST['vars'];
                       $begin_date=$_POST['begin_date'];
                       $end_date=$_POST['end_date'];
                       $user=$_POST['user'];
                       $campaignid=$_POST['campaignid'];
                       $status=$_POST['status'];
               	    $funcName($vars,$begin_date,$end_date,$user,$campaignid);
               	}
               	mysqli_close($link);
               	//exit;
               	?>	 
      </table>
      </div>
      <script src="./jquery.js"></script>
      <script src="./jquery.datetimepicker.js"></script>
      <script>
         $('.date_class').datetimepicker({
         	format : 'd-m-Y H:i:s',
         	formatTime:'H:i',
         	formatDate:'d-m-Y'
         
         });
      </script>
      <script language="javascript">
         function downloads()
         {
         
         	var download=document.admin.download.value;
         	var begin_date=document.fone.b_date.value;
         	var end_date=document.fone.e_date.value;
         	var user = document.fone.user.value;
         	var campaign_id=document.fone.campaign.value;
         	var did=document.fone.did.value;
         	var queue=document.fone.queue.value;
         	var stats=document.fone.status.value;
         
         
         	window.location.href="DownloadInboundReport.php?start_date="+begin_date+"&end_date="+end_date+"&user="+user+"&campaignid="+campaign_id+"&did="+did+"&queue="+queue+"&status="+stats;
         }
         
         function nextpre(url)
            {
            	document.admin.action=url;
                //alert(url);
                document.admin.submit();
            }
         
         
         	
          
      </script>
      <script language="JavaScript" src="calendar1.js"></script>
      <SCRIPT src="test.js" type='text/javascript'></SCRIPT>
      <script language="JavaScript" src="calendar1.js"></script>
      <!-- Datatable by farhan:03-02-2021 -->
      <!-- <script src="dist/js/app.min.js"></script> -->
      <!--nprogress-->
      <script src="dist/js/nprogress.js"></script>
      <!--file dropify-->
      <script src="dist/js/dropify.min.js"></script>
      <script type="text/javascript" src="dist/datatables/js/jquery.dataTables.min.js"></script>
      <script type="text/javascript" src="dist/datatables/js/dataTables.buttons.min.js"></script>
      <script type="text/javascript" src="dist/datatables/js/jszip.min.js"></script>
      <script type="text/javascript" src="dist/datatables/js/pdfmake.min.js"></script>
      <script type="text/javascript" src="dist/datatables/js/vfs_fonts.js"></script>
      <script type="text/javascript" src="dist/datatables/js/buttons.html5.min.js"></script>
      <script type="text/javascript" src="dist/datatables/js/buttons.print.min.js"></script>
      <script type="text/javascript" src="dist/datatables/js/buttons.colVis.min.js" ></script>
      <script type="text/javascript" src="dist/datatables/js/dataTables.responsive.min.js" ></script>
      <script type="text/javascript" src="dist/datatables/js/ss.custom.js" ></script>
      <!-- End -->
      <script language="JavaScript">
         function detail(dis,begin_date,end_date,user,campaignid,status)
         {
         
         	var url="<?php echo $_SERVER[PHP_SELF];?>?action=detail&vars="+dis+"&begin_date="+begin_date+"&end_date="+end_date+"&user="+user+"&campaignid="+campaignid+"&status="+status;
            window.open(url, "_self");
         
         } 
         
         var cal1 = new calendar1(document.forms['admin'].elements['start_date']);
         cal1.year_scroll = true;
         cal1.time_comp = false;
         var cal2 = new calendar1(document.forms['admin'].elements['end_date']);
         cal2.year_scroll = true;
         cal2.time_comp = false;
         
         
         
      </script>
      <?include("footer.php")?>
   </body>
</html>