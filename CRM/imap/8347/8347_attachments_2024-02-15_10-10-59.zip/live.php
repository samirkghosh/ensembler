<?
   // require_once("dbconnect.php");
 require_once("mysql_connect.php");
   
   $dt=date("Y-m-d");
   
   $q=mysqli_fetch_row(mysqli_query($link,"select count(*) from autodial_auto_calls WHERE call_type = 'IN' and status='LIVE' ;"));
   $var1=$q[0];
   
   $q=mysqli_fetch_row(mysqli_query($link,"select (UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(call_time)) from autodial_auto_calls where call_type = 'IN' and status='LIVE' order by auto_call_id asc limit 0,1 ;"));
   $var2=gmdate("H:i:s",$q[0]);
   
   $q=mysqli_fetch_row(mysqli_query($link,"select count(*) from autodial_live_agents where status='INCALL' AND hold_status='yes';"));
   $var3=$q[0];
   
   /*------------------------------------------- in outbound----------------------------------------------------------*/
   
   $q=mysqli_fetch_row(mysqli_query($link,"select count(closecallid) from autodial_closer_log where status in ('QUEUE','DROP') and call_date like '%$dt%' ;"));
   $var4=$q[0];
   
   //$q=mysqli_fetch_row(mysqli_query($link,"select count(v_SessionId) from tbl_cdrlog where status='VOICE MAIL' and d_StartTime like '%$dt%' and v_SessionId not in (select v_SessionId from vicidial_closer_log where status in ('QUEUE','DROP') AND call_date like '%$dt%' )"));
   //"select count(id) from tbl_cc_voicemails where voicemailtime like '%$dt%' and mailid_info='queue'";

   //voicemail code written below for voicemail
   // $q=mysqli_fetch_row(mysqli_query($link,"select count(id) from tbl_cc_voicemails where voicemailtime like '%$dt%' and flag1='0' "));
   // $var4_1=$q[0];
   
   $q=mysqli_fetch_row(mysqli_query($link,"select count(v_SessionId) from tbl_cdrlog where status in ('MISSED CALL','NO ANSWER') and  missedcallcause = 'CALLER DISCONNECTED IN QUEUE' and d_StartTime like '%$dt%'"));
   $var4_2=$q[0];
   
   //$q=mysqli_fetch_row(mysqli_query($link,"select count(v_SessionId) from tbl_cdrlog where status='BUSY' and d_StartTime like '%$dt%' and v_SessionId not in (select v_SessionId from vicidial_closer_log where status in ('QUEUE','DROP') AND call_date like '%$dt%' )"));
   $q=mysqli_fetch_row(mysqli_query($link,"select count(v_SessionId) from voiceloger where status in ('NO ANSWER','BUSY') and start_time like '%$dt%' and typeofcall='IN' and local<>'1';"));
   $var4_3=$q[0];
   
   $q=mysqli_fetch_row(mysqli_query($link,"select count(closecallid) from autodial_closer_log where call_date like '%$dt%' AND status in ('DONE','INCALL');"));
   $var4_4=$q[0];
   
   //$q=mysqli_fetch_row(mysqli_query($link,"select count(v_SessionId) from tbl_cdrlog where d_StartTime like '%$dt%' AND (status is not NULL OR status<>'');"));
   $q=mysqli_fetch_row(mysqli_query($link,"select count(closecallid) from autodial_closer_log where call_date like '%$dt%';"));
   $var5=$q[0];
   
   /*-------------------------*/
   
   // $q1=mysqli_fetch_row(mysqli_query($link,"select count(sno) from voiceloger where start_time like '%$dt%' and status='ANSWERED' and local<>'1' and typeofcall='OUT';"));
   // $q2=mysqli_fetch_row(mysqli_query($link,"select count(recording_id) from recording_log where start_time like '%$dt%' and (did_name is NULL);"));
   
   // $var17=$q1[0]+$q2[0];
   
   // $q=mysqli_fetch_row(mysqli_query($link,"select count(sno) from voiceloger where start_time like '%$dt%' and typeofcall='OUT' and local<>'1' and status<>'ANSWERED';"));
   // $var17_1=$q[0];
   
   // $q=mysqli_fetch_row(mysqli_query($link,"select count(sno) from voiceloger where start_time like '%$dt%' and typeofcall='OUT' and local<>'1' and (status<>'' or status is not NULL);"));
   // $var17_2=$q[0];


      /* Modified for correct outbound answered and non answered calls*/
      $q1=mysqli_fetch_row(mysqli_query($link,"select count(recording_id) from recording_log where start_time like '%$dt%' and location IN ('Connected','Transfer') and call_type IN('dialpad','c2c')"));
      $var17 = $q1[0];
      
      // $q=mysqli_fetch_row(mysqli_query($link,"select count(sno) from voiceloger where start_time like '%$dt%' and typeofcall='OUT' and local<>'1' and status<>'ANSWERED';"));
      $q=mysqli_fetch_row(mysqli_query($link,"select count(recording_id) from recording_log where start_time like '%$dt%' and location NOT IN ('Connected','Transfer') and call_type IN('dialpad','c2c')"));
      $var17_1=$q[0];
      
      $q=mysqli_fetch_row(mysqli_query($link,"select count(sno) from voiceloger where start_time like '%$dt%' and typeofcall='OUT' and local<>'1' and (status<>'' or status is not NULL);"));
      $var17_2=$q[0];
   
   /*------------------------------------------- in outbound----------------------------------------------------------*/
   
   $q=mysqli_fetch_row(mysqli_query($link,"select count(v_SessionId) from tbl_cdrlog where d_StartTime like '%$dt%' and toc IS NOT NULL;"));
   $var6=$q[0]; 
   
   $q=mysqli_fetch_row(mysqli_query($link,"SELECT AVG(UNIX_TIMESTAMP(`d_EndTime`)-UNIX_TIMESTAMP(`d_StartTime`)) FROM `tbl_cdrlog` where d_StartTime like'%$dt%' and status NOT IN ('ANSWERED','VOICEMAIL') AND d_EndTime NOT IN('NULL','0000-00-00 00:00:00');"));
   $var7=gmdate("H:i:s",$q[0]);
   
   /*$q=mysqli_fetch_row(mysqli_query($link,"SELECT AVG(UNIX_TIMESTAMP(`answered_time`)-UNIX_TIMESTAMP(`d_StartTime`)) FROM `tbl_cdrlog` where status='ANSWERED' and d_StartTime like'%$dt%' and answered_time NOT IN('NULL','0000-00-00 00:00:00');"));
   $var8=gmdate("H:i:s",$q[0]);*/
   
   $q=mysqli_fetch_row(mysqli_query($link,"select SUM(UNIX_TIMESTAMP(`end_time`)-UNIX_TIMESTAMP(`answered_time`)) , AVG(UNIX_TIMESTAMP(`end_time`)-UNIX_TIMESTAMP(`answered_time`)) FROM voiceloger where start_time like '%$dt%' and  local<>'1' and status='ANSWERED' and length_in_sec>0 ;"));
   $vars=$q[0]; $varss=$q[1];
   
   $q=mysqli_fetch_row(mysqli_query($link,"select SUM(length_in_sec) , AVG(length_in_sec) FROM recording_log where start_time like '%$dt%' and length_in_sec>0 ;"));
   $vars1=$q[0]; $varss1=$q[1];
   
   $var9=gmdate("H:i:s",($vars+$vars1));
   
   $var10=gmdate("H:i:s",($varss+$varss1));
   //echo "select count(*) from vicidial_live_agents;";
   $q=mysqli_fetch_row(mysqli_query($link,"select count(*) from autodial_live_agents;"));
   $var11=$q[0];
   
   $q=mysqli_fetch_row(mysqli_query($link,"select count(*) from autodial_live_agents where status='READY';"));
   $var12=$q[0];
   
   $q=mysqli_fetch_row(mysqli_query($link,"select count(*) from autodial_live_agents where status='INCALL';"));
   $var13=$q[0];
   
   $q=mysqli_fetch_row(mysqli_query($link,"select count(*) from autodial_live_agents where status='WRAPUP';"));
   $var14=$q[0];
   
   $q=mysqli_fetch_row(mysqli_query($link,"SELECT AVG(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(pausereadytime)) FROM `autodial_live_agents` WHERE status='READY';"));
   $var15=gmdate("H:i:s",$q[0]);
   
   $q=mysqli_fetch_row(mysqli_query($link,"SELECT AVG(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(last_call_time)) FROM `autodial_live_agents` WHERE status='INCALL';"));
   $var16=gmdate("H:i:s",$q[0]);




   /* Modification in live dashboard on 10-03-2023 for correcting call details */

   // ivr abandon
   

   $begin_date1= date("Y-m-d 00:00:00");
   $begin_date2= date("Y-m-d 23:59:59");

   $rowt=mysqli_fetch_row(mysqli_query($link,"select count(*) as ivrs_abandonCalls  from tbl_cdr cd join tbl_cdrlog cdl on cdl.v_SessionId = cd.uniqueid  where d_StartTime>= '$begin_date1' and d_StartTime<= '$begin_date2' and (cdl.status='NO ANSWER' OR cdl.status='MISSED CALL') and cdl.missedcallcause = 'CALL DISCONNECTED' "));
   $ivrs_abandonCalls_total=$rowt[0];


   $stmt="select DATE(call_date),count(*) as Total_INCOMING_Calls,
   sum(case when status in ('DONE','INCALL') then 1 else 0 end) as Converts,
   sum(case when status in ('AGENT DROP') then 1 else 0 end) as AGENT_DROP,
   sum(case when status in ('QUEUE') then 1 else 0 end) as DROPS,
   sum(case when status in ('DROP') then 1 else 0 end) as QueueMaxAchieve,campaign_id
   from autodial_closer_log
   where call_date >= '$begin_date1' and call_date <= '$begin_date2' order by campaign_id asc";

   $rslt=mysqli_query($link,$stmt);
   $row=mysqli_fetch_row($rslt);

   $connected_total=$row[2];//connected
   $agentDrops_total=$row[3];//agentdrop
   $systenQueueDrops_total=$row[5];//drop
   $customerQueueDrops_total=$row[4];//queee


   $service ="select count(*) as service  from tbl_cdr   where start_time>= '$begin_date1' and end_time<= '$begin_date2' and status IN ('SERVICING') ";
   $service=mysqli_query($link,$service);
   $service_result  = mysqli_fetch_assoc($service);
   $total_service =   $service_result['service'] ;

   $Forwarding ="select count(*) as forwarded  from tbl_cdr   where start_time>= '$begin_date1' and end_time<= '$begin_date2' and status IN ('FORWARDING') ";
   $Forwarding = mysqli_query($link,$Forwarding);
   $forwarding_result  = mysqli_fetch_assoc($Forwarding);
   $total_forwarding =   $forwarding_result['forwarded'] ;



      /*voicemail*/
      $stmv = "select count(*) as non_officehour_voicmail from tbl_cdrlog where  
      d_EndTime>= '$begin_date1' and d_EndTime<= '$begin_date2' AND missedcallcause='VOICEMAIL_nonofficehours' ";
      $rowVQuery = mysqli_query($link, $stmv) or die('Err while excecuting non office hour voicemail' . mysqli_error($link));
      $rowv = mysqli_fetch_row($rowVQuery);
   
      $non_officehour_total_voicemail = $rowv[0];



   /* Total no of inbound connected  */

   $total_abandoned=( ($connected_total+$total_service + $total_forwarding) +$agentDrops_total+$systenQueueDrops_total+$customerQueueDrops_total+$ivrs_abandonCalls_total+$non_officehour_total_voicemail);

 


   /*End */
   
   
   
   ?>
<style>
   .block{
   width:32%;
   float:left;
   height:148px;
   color:#ffffff;
   margin-right:1%;
   margin-bottom:14px;
   }
   .head{
   height:30px;
   padding:4px;
   border-bottom:3px solid #ffffff;
   line-height:30px;
   font-weight:bold;
   /*transform:scale(1,2);*/
   }
   .logo,.value{ width:20%; float:left; padding:10px; font-size:51px; line-height:63px; }
   .value{ text-align:right; width:66% !important; }
   .bottom{ clear:both; text-align:right; background:#222; padding:4px; font-size:12px; line-height:20px; }
   .block-1{ background:#f09b40; }
   .block-2{ background:#e35b5a; }
   .block-3{ background:#44b6ae; }
   .block-4{ background:#4f6cac; }
   .block-5{ background:#6cad53; }
   .block-6{ background:#7f67aa; }
   .block-7{ background:#33aabc; }
   .block-8{ background:#aa5ba7; }
   .block-9{ background:#a9a342; }
   .block-10{ background:#a2324c; }
   .block-11{ background:#c373e4; }
   .block-12{ background:#35a971; }
   .block-13{ background:#f09b40; }
   .block-14{ background:#e35b5a; }
   .block-15{ background:#44b6ae; }
   .block-16{ background:#4f6cac; }
   .block-17{ background:#6cad53; }
   .block-18{ background:#7f67aa; }
   .block-19{ background:#33aabc; }
</style>

<div class="block block-6">
   <div class="head">INBOUND CALLS</div>
   <div class="main">
      <div class="logo"><img src="DASHBOARD_ICONS/Inbound_calls.png" height='60' border='0'></div>
      <!-- <div class="value"><? //$var5?></div> -->
      <div class="value"><?=$total_abandoned?></div>
   </div>
   <!-- <div class="bottom">&nbsp;</div>-->
</div>

<div class="block block-16">
   <div class="head">INBOUND ANSWERED</div>
   <div class="main">
      <div class="logo"><img src="DASHBOARD_ICONS/Inbound_answered.png" height='60' border='0'></div>
      <div class="value"><?=$var4_4?></div>
   </div>
   <!-- <div class="bottom">&nbsp;</div>-->
</div>

<div class="block block-4">
   <div class="head">CUSTOMER INBOUND ABANDONED CALLS</div>
   <div class="main">
      <div class="logo"><img src="DASHBOARD_ICONS/INbound_abandoned.png" height='60' border='0'></div>
      <div class="value"><?=$customerQueueDrops_total+$ivrs_abandonCalls_total?></div>
   </div>
   <!--<div class="bottom">&nbsp;</div>-->
</div>

<div class="block block-7">
   <div class="head">INBOUND MISSEDCALL</div>
   <div class="main">
      <div class="logo"><img src="DASHBOARD_ICONS/INbound_abandoned.png" height='60' border='0'></div>
      <div class="value"><?=$agentDrops_total+$systenQueueDrops_total?></div>
   </div>
   <!-- <div class="bottom">&nbsp;</div>-->
</div>

<div class="block block-1">
   <div class="head">AGENT WAITING NOW</div>
   <div class="main">
      <div class="logo"><img src="DASHBOARD_ICONS/Waiting_Now.png" height='60' border='0'></div>
      <div class="value"><?=$var1?></div>
   </div>
   <!--<div class="bottom">&nbsp;</div>-->
</div>
<div class="block block-2">
   <div class="head">LONGEST WAITING</div>
   <div class="main">
      <div class="logo"><img src="DASHBOARD_ICONS/longest-waiting.png" height='60' border='0'></div>
      <div class="value"><?=$var2?></div>
   </div>
   <!-- <div class="bottom">&nbsp;</div>-->
</div>
<div class="block block-3">
   <div class="head">HOLD CALLS</div>
   <div class="main">
      <div class="logo"><img src="DASHBOARD_ICONS/Answered_Now.png" height='60' border='0'></div>
      <div class="value"><?=$var3?></div>
   </div>
   <!-- <div class="bottom">&nbsp;</div>-->
</div>

<div class="block block-17">
   <div class="head">INBOUND VOICE CALLS</div>
   <div class="main">
      <div class="logo"><img src="DASHBOARD_ICONS/INbound_abandoned.png" height='60' border='0'></div>
      <!-- <div class="value"><?=$var4_1?></div> -->
      <div class="value"><?=$non_officehour_total_voicemail?></div>
   </div>
   <!-- <div class="bottom">&nbsp;</div>-->
</div>

<div class="block block-9">
   <div class="head">INBOUND NO ANSWER/BUSY</div>
   <div class="main">
      <div class="logo"><img src="DASHBOARD_ICONS/INbound_abandoned.png" height='60' border='0'></div>
      <div class="value"><?=$var4_3?></div>
   </div>
   <!--<div class="bottom">&nbsp;</div>-->
</div>


<div class="block block-11">
   <div class="head">OUTBOUND ANSWERED</div>
   <div class="main">
      <div class="logo"><img src="DASHBOARD_ICONS/Inbound_calls.png" height='60' border='0'></div>
      <div class="value"><?=$var17?></div>
   </div>
   <!-- <div class="bottom">&nbsp;</div>-->
</div>
<div class="block block-13">
   <div class="head">OUTBOUND NO ANSWER/BUSY</div>
   <div class="main">
      <div class="logo"><img src="DASHBOARD_ICONS/Inbound_calls.png" height='60' border='0'></div>
      <div class="value"><?=$var17_1?></div>
   </div>
   <!-- <div class="bottom">&nbsp;</div>-->
</div>
<!--
   <div class="block block-10">
           <div class="head">OUTBOUND CALLS</div>
           <div class="main"><div class="logo"><img src="DASHBOARD_ICONS/Inbound_calls.png" height='60' border='0'></div><div class="value"><?=$var17_2?></div></div>
          <!-- <div class="bottom">&nbsp;</div>-->
<!--</div>-->
<div class="block block-7">
   <div class="head">AVG ABANDONED TIME</div>
   <div class="main">
      <div class="logo"><img src="DASHBOARD_ICONS/Avg_abandoned_Time.png" height='60' border='0'></div>
      <div class="value"><?=$var7?></div>
   </div>
   <!-- <div class="bottom">&nbsp;</div>-->
</div>
<!--
   <div class="block block-8">
           <div class="head">AVG ANSWER TIME</div>
           <div class="main"><div class="logo"><img src="DASHBOARD_ICONS/Avg_Answer_Time.png" height='60' border='0'></div><div class="value"><?=$var8?></div></div>
          <!-- <div class="bottom">&nbsp;</div>-->
<!--</div>-->
<div class="block block-12">
   <div class="head">SIGN-IN COUNT</div>
   <div class="main">
      <div class="logo"><img src="DASHBOARD_ICONS/sign-in_count.png" height='60' border='0'></div>
      <div class="value"><?=$var11?></div>
   </div>
   <!--  <div class="bottom">&nbsp;</div>-->
</div>
<div class="block block-10">
   <div class="head">TOTAL TALK TIME</div>
   <div class="main">
      <div class="logo"><img src="DASHBOARD_ICONS/Total_talk_time.png" height='60' border='0'></div>
      <div class="value"><?=$var9?></div>
   </div>
   <!-- <div class="bottom">&nbsp;</div>-->
</div>
<div class="block block-11">
   <div class="head">AVG TALK TIME</div>
   <div class="main">
      <div class="logo"><img src="DASHBOARD_ICONS/average_talk_time.png" height='60' border='0'></div>
      <div class="value"><?=$var10?></div>
   </div>
   <!-- <div class="bottom">&nbsp;</div>-->
</div>
<div class="block block-14">
   <div class="head">IN AVAILABLE (READY)</div>
   <div class="main">
      <div class="logo"><img src="DASHBOARD_ICONS/In_available.png" height='60' border='0'></div>
      <div class="value"><?=$var12?></div>
   </div>
   <!--   <div class="bottom">&nbsp;</div>-->
</div>
<div class="block block-15">
   <div class="head">IN BUSY</div>
   <div class="main">
      <div class="logo"><img src="DASHBOARD_ICONS/In_busy.png" height='60' border='0'></div>
      <div class="value"><?=$var13?></div>
   </div>
   <!--    <div class="bottom">&nbsp;</div>-->
</div>
<div class="block block-19">
   <div class="head">IN WRAP-UP</div>
   <div class="main">
      <div class="logo"><img src="DASHBOARD_ICONS/In_wrap-up.png" height='60' border='0'></div>
      <div class="value"><?=$var14?></div>
   </div>
   <!--      <div class="bottom">&nbsp;</div>-->
</div>

<script>

setTimeout(function(){
   window.location.reload(1);
}, 5000);

</script>
