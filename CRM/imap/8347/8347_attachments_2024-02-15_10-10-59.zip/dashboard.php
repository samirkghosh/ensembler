<style>
   .naming{
   font-weight:bold; color:#222;
   font-weight:normal;
   width:35%;
   border:0 !important;
   }
   .mydiv{
   width:15px;
   margin-right:19px;
   margin-bottom:5px;
   float:left;
   border:1px solid #999999;
   }
   .mydiv1{
   width:auto !important;
   margin-left:14px !important;
   border:0 !important;
   }
   .box{
   height:15px; margin-left:4px;
   }
   .pri_span{ float:left; margin-right:15px; margin-top:1px; }
</style>
<?	

   /* remove NULL, FALSE and Empty Strings (""), but leave values of 0 (zero) from an array and returns re-index array */
   function filter($arr) 
   {
	$outputArray = array_filter($arr, function($value) {
		// Keep values that are not NULL, FALSE, or an empty string, but keep 0.
		return ($value !== NULL && $value !== FALSE && $value !== "");
	});
	
	// Re-index the array to reset keys if needed.
	return $outputArray = array_values($outputArray);
   }
   
   
   $green="<img src='img/green.png' width='16' align='absmiddle'>";
   $red="<img src='img/red.png' width='16' align='absmiddle'>";
   
   echo "<TABLE width='100%' borde='0'><TR><TD>\n";
   	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=white SIZE=2>";
   	
   echo "<br><center><TABLE width=\"100%\" cellspacing=2 cellpadding=4 style=\"font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:normal;  height:24px; \"><tr><td align='left' style='font-size:16px;'>System Status:</td><td align='right'>r1 -> PRI on port 1&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; r3 -> PRI on port 3</td></tr></table>
   <div id=''>
   <!--<div id='latestData'>-->
   <TABLE width=\"100%\" style=\"font-family:Verdana, Arial, Helvetica, sans-serif;\">
   
   <tr>
   	<td align='left' valign='top' width='50%'>
   		<form name='myform' method='post'>	
   		<TABLE width=\"100%\" cellspacing=2 cellpadding=4 style='border:solid thin #999999; background:#fff; margin-bottom:15px;'>
   			<tr style=\"background:#083b82; height:24px; \">
   				<td valign='top'  style='color:#ffffff; font-size:12px;' colspan='2'>Trunk Status</td>
   			</tr>
   			<tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top'  class='naming'>PRI Status</td>
   				<td valign='top' >";
   			
							$filename1="/var/www/html/tmp/pri.txt";
							$numberOfPriAvailable=0;

							$handle = fopen($filename1, "r");
							if (trim($handle)) {
								$index=1;
								while (($line = fgets($handle)) !== false) {
									$index++;
								}
								if ($index==1) {
									echo "No PRI available.";
								}else{
									echo ($index-1)." PRI available.";
								}
								fclose($handle);
							} else {
								echo "No PRI available.";
							} 
   
                                   //echo filesize($filename1);
                                   $cnt=0;
                                   if(file_exists($filename1))
                                   { 
                                           $file1=fopen($filename1,'r');
                                           $contentt=fread($file1,filesize($filename1));
                                           $line = fgets($file1);
                                           //print_r($line);
                                           $intpos=strpos($contentt,"No such command");
                                           //$contentt=fread($file1,filesize($filename)); 
   
                                           if (0 == filesize($filename1))
                                           {
                                                  // echo "No PRI available.";
                                           }
                                           else {
                                                   if(is_int($intpos)){ echo "No PRI available."; }
                                                   else
                                                   {
                                                   while(!feof($file1))
                                                   {
                                                           $line_of_text = fgets($file1);
                                                           if(trim($line_of_text)!=""){ $cnt++; }
                                             //              echo ($index-1)." akas";
                                                   }
                                                   }
                                           }
   
                                   }
                                 /*  if($cnt<=0 && !is_int($intpos)){
                                   echo "No PRI available.";
                                   }*/
                                   $content="";
   
   		   echo "</td>
   		   </tr>
   		   <tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top'  class='naming'>SIP Trunk Status</td>
   				<td valign='top' >";
   							
   				$filename2="/tmp/sip.txt";
   				$filename2="/var/www/html/tmp/sip.txt";
   
   				//$filename2="/tmp/sip.txt";
   
   				if(file_exists($filename2))
   				{
   					
   					$file2=fopen($filename2,'r');
   					$contentt=fread($file,filesize($filename2)); 
   					$intpos=strpos($contentt,"No such command");
   					//$contentt=fread($file1,filesize($filename)); 
   					if (0 == filesize($filename2))
   					{
   						echo "No SIP Trunk available.";
   					}
   					else {
   						
   						if(is_int($intpos)){ echo "No SIP Trunk available."; }
   						else
   						{
   						while(!feof($file2))
   						{
   							echo $line_of_textdk = fgets($file2);
   						}
   						}
   					}
   					
   					
   				}
   				$content="";
   				
   			
   		   echo "</td>
   		   </tr>
   		   <tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top'  class='naming'>GSM Trunk Status</td>
   				<td valign='top' >";
   				$filename21="/tmp/gsm.txt";
   				$filename21="/var/www/html/tmp/gsm.txt";
   				if(file_exists($filename21))
   				{
   					
   					$file21=fopen($filename21,'r');
   					$contentt=fread($file21,filesize($filename21)); 
   					$intpos=strpos($contentt,"No such command");
   					if (0 == filesize($filename21))
   					{
   						echo "No GSM Trunk available.";
   					}
   					else {
   					
   					if(is_int($intpos)){ echo "No GSM Trunk available."; }
   					else
   					{
   						while(!feof($file21))
   						{
   							echo $line_of_textdk1 = fgets($file21);
   						}
   						
   					}
   					
   					}
   					
   					
   				}
   				$content="";
   		   echo "</td>
   		   </tr>
   
   		   <tr style='font-size:12px; background-color:#ffffff;'>
                                   <td valign='top'  class='naming'><span style='display:none'>PRI Group Status</span></td>
                                   <td valign='top' ><span style='display:none'>";
                                   
   				$call_failed=15;
   				$call_status_array=array('ANSWERED','BUSY');
   				$qu=mysqli_query($link,"select distinct trunk from voiceloger where ( trunk<>'' ) order by trunk asc ;");
   				while($re=mysqli_fetch_row($qu))
   				{
   				$company=$re[0];
   				$query=mysqli_query($link,"SELECT status FROM voiceloger where trunk='$company' order by sno desc limit 0,$call_failed ;");
   				$num=mysqli_num_rows($query);
   				$n1=0; $cnt=0;
   				while($res=mysqli_fetch_row($query))
   				{
   				$n1++;
                                   $status=$res[0]; 
   				if(!in_array($status,$call_status_array)){ $cnt++; }
   
   				if($n1==$num) { if($cnt==$call_failed) { echo "<div class='pri_span'>".$red." ".$company." is DOWN</div>"; } else { echo "<div class='pri_span'>".$green." ".$company." is UP</div>"; } }
   
   				}
   
   				}
   				
                                   $content="";
                      echo "</span></td>
                      </tr>
   		
   		   <tr style='font-size:12px; background-color:#ffffff; display:none'>
                                   <td valign='top'  class='naming'>Switch Load On</td>
                                   <td valign='top' >";
   
   				if(isset($_POST['switchload']))
   				{
   					$switchload=$_POST['switchload'];
   					mysqli_query($link,"update tbl_custom_route set group_id='$switchload'; ");
   				}
   
   				$r1=""; $r3="";$both="";
   				$r=mysqli_query($link,"select group_id from tbl_custom_route group by group_id");
   				$num_1=mysqli_num_rows($r);
   				$ress=mysqli_fetch_row($r);
   				if($num_1==1){ if($ress[0]=='13'){$both="checked";} if($ress[0]=='r1'){ $r1="checked"; } if($ress[0]=='r3'){ $r3="checked"; } }
   				
   
   		   echo "	<input type='radio' name='switchload' value='r1' style='vertical-align:middle;' $r1 onclick=\"document.forms['myform'].submit();return false;\"> r1 &nbsp;&nbsp;
   				<input type='radio' name='switchload' value='r3' style='vertical-align:middle;' $r3 onclick=\"document.forms['myform'].submit();return false;\"> r3 &nbsp;&nbsp;
   				<input type='radio' name='switchload' value='13' style='vertical-align:middle;' $both onclick=\"document.forms['myform'].submit();return false;\"> both &nbsp;&nbsp;
   				</td>
                      </tr>
   
   		</TABLE>
   		</form>
   		
   	</td>
   	<td align='left' valign='top'>
   		
   		<TABLE width=\"100%\" cellspacing=2 cellpadding=4 style='border:solid thin #999999; background:#fff; margin-bottom:15px;'>
   			<tr style=\"background:#083b82; height:24px; \">
   				<td valign='top'  style='color:#ffffff; font-size:12px;' colspan='2'>System Statistics</td>
   			</tr>
   			<tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top'  class='naming'>Load Avg.</td>
   				<td valign='top' >";
   				$filename="/tmp/loadavg.txt";
   				$filename="/var/www/html/tmp/loadavg.txt";
   
   				if(file_exists($filename))
   				{
   					$file=fopen($filename,'r');
   					$contentt=fread($file,filesize($filename)); 
   					$intpos=strpos($contentt,"No such command");
   					if (0 == filesize($filename))
   					{
   						echo "No PRI available.";
   					}
   					else {
   					if( (is_int($intpos) || is_int(strpos($contentt,"Unable to connect")))  || trim($contentt)==''){ echo $red." Not available"; }else {
   					
   					$content = explode(',', $contentt);
   					$cont=$content[1];
   					if($cont>=0 && $cont<=5){ echo $green; }else if( $cont>5 && $cont<=15 ){ echo $orange; }else{ echo $red; } echo " ".$cont;
   					 
   					 }
   					 }
   				}
   				
   				$content="";
   		   echo "</td>
   		   </tr>
   		   <tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top'  class='naming'>Memory</td>
   				<td valign='top' >";
   				
   				$filename="/tmp/disc.txt";
   				$filename="/var/www/html/tmp/disc.txt";
   
   				if(file_exists($filename))
   				{
   					$file=fopen($filename,'r');
   					$contentt=fread($file,filesize($filename)); 
   					$intpos=strpos($contentt,"No such command");
   					if (0 == filesize($filename))
   					{
   						echo "No PRI available.";
   					}
   					else {
   					if( (is_int($intpos) || is_int(strpos($contentt,"Unable to connect")))  || trim($contentt)==''){ echo $red." Not available"; }else {
   					
   					$n=explode('Mounted on',$contentt);
   					$nn=explode("%",$n[1]);
   					//print_r($nn);
   					$size=sizeof($nn);
   					$size--;
   					for($i=0; $i<$size; $i++)
   					{
   						//$digi=substr($nn[$i],-1);
						$ttt = explode(" ",$nn[$i]);
   						$digi=end($ttt);
   						
   						//echo '<br>val'.$snip = substr($nn[$i], strpos($nn[$i], "%"), -1);
   						$sm=$sm+$digi;
   					}
   					$cont=$sm;
   					if($cont>=0 && $cont<=50){ echo $green; }else if( $cont>50 && $cont<=80 ){ echo $orange; }else{ echo $red; } echo " ".$cont."%";
   					
   					}
   					}
   				}
   				
   				$content="";			
   		   echo "</td>
   		   </tr>
   		   <tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top'  class='naming'>RAM Usage</td>
   				<td valign='top' >";
   				$filename="/tmp/ram.txt";
   				$filename="/var/www/html/tmp/ram.txt";
   
   				if(file_exists($filename))
   				{
   					$file=fopen($filename,'r');
   					$contentt=fread($file,filesize($filename)); 
   					$intpos=strpos($contentt,"No such command");
   					if (0 == filesize($filename))
   					{
   						echo "No PRI available.";
   					}
   					else {
   					if( (is_int($intpos) || is_int(strpos($contentt,"Unable to connect")))  || trim($contentt)==''){ echo $red." Not available"; }else { 
   					
   					$content = preg_replace('/\s\s+/',' ', $contentt);
   					$content = explode(' ', $content);
   					
   					echo "Used: ".$content[2]." M / Total: ".$content[1]." M";
   					
   					 }
   					 }
   					
   				}
   				$content="";
   		   echo "</td>
   		   </tr>
   		   <tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top'  class='naming'>Swap</td>
   				<td valign='top' >";
   				$filename="/tmp/swap.txt";
   				$filename="/var/www/html/tmp/swap.txt";
   
   				if(file_exists($filename))
   				{
   					$file=fopen($filename,'r');
   					$contentt=fread($file,filesize($filename)); 
   					$intpos=strpos($contentt,"No such command");
   					if (0 == filesize($filename))
   					{
   						echo "No PRI available.";
   					}
   					else {
   					if( (is_int($intpos) || is_int(strpos($contentt,"Unable to connect")))  || trim($contentt)==''){ echo $red." No PRI trunk available"; }else {
   					
   					$content = preg_replace('/\s\s+/',' ', $contentt);
   					$content = explode(' ', $content);
   					//print_r($content);
   					$cont=$content[2];
   					echo "Used: ".$cont." M / Total: ".$content[1]." M";
   					
   					}
   					}
   					//$arr=explode(',',$content);
   					//$VD_login=$arr[0];
   					//$VD_pass=$arr[1];
   					//$phone_login=$arr[2];
   				}
   								
   				$content="";
   		   echo "</td>
   		   </tr>
   		</TABLE>
   		
   	</td>
   </tr>
   
   <tr>
   	<td valign='top'  align='left' valign='top'>
   		
   		<TABLE width=\"100%\" cellspacing=2 cellpadding=4 style='border:solid thin #999999; background:#fff; margin-bottom:15px;'>
   			<tr style=\"background:#083b82; height:24px; \">
   				<td valign='top'  style='color:#ffffff; font-size:12px;' colspan='2'>Uptime</td>
   			</tr>
   			<tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top'  class='naming'>System Uptime</td>
   				<td valign='top' >";
   				$filename="/tmp/systemup.txt";
   				$filename="/var/www/html/tmp/systemup.txt";
   
   				if(file_exists($filename))
   				{
   					$file=fopen($filename,'r');
   					$contentt=fread($file,filesize($filename)); 
   					$intpos=strpos($contentt,"No such command");
   					if (0 == filesize($filename))
   					{
   						echo "Not available.";
   					}
   					else {
   					
   					if( (is_int($intpos) || is_int(strpos($contentt,"Unable to connect")))  || trim($contentt)==''){ echo $red." Not available."; }else { echo $green." ".$contentt; }
   					
   					}
   					//$arr=explode(',',$content);
   					//$VD_login=$arr[0];
   					//$VD_pass=$arr[1];
   					//$phone_login=$arr[2];
   				}
   				$content="";
   		   echo "</td>
   		   </tr>
   		   <tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top'  class='naming'>Asterisk Uptime</td>
   				<td valign='top' >";
   				$filename="/tmp/asteriskup.txt";
   				$filename="/var/www/html/tmp/asteriskup.txt";
   				$asteriskstatus=$red." Not running";
   				if(file_exists($filename))
   				{
   					$file=fopen($filename,'r');
   					$contentt=fread($file,filesize($filename)); 
   					$intpos=strpos($contentt,"No such command");
   					$content=explode('System uptime: ',$contentt);
   					$content=explode('Last reload: ',$content[1]);
   					if (0 == filesize($filename))
   					{
   						echo "Not available.";
   					}
   					else {
   					if( (is_int($intpos) || is_int(strpos($contentt,"Unable to connect")))  || trim($contentt)==''){ echo $red." Not available"; }else { 
   					$asteriskstatus=$green." OK";
   					echo $green." ".$content[0]; 
   					
   					}
   					}
   					
   				}
   				
   		   echo "</td>
   		   </tr>
   		   <tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top'  class='naming'>Last reload</td>
   				<td valign='top' >";
   				if (0 == filesize($filename))
   					{
   						echo "Not available.";
   					}
   					else {
   				if( (is_int($intpos) || is_int(strpos($contentt,"Unable to connect")))  || trim($contentt)==''){ echo $red." Not available"; }else { 
   					
   					echo $green." ".$content[1]; 
   					
   					}
   					}
   								
   				$content="";
/* Changes Made for Disk Utility Record View on :: 29-08-2023 
##############################################################
Start
*/
				$DiskUtilityContent = [];
   				exec("cat /var/www/html/tmp/disc.txt", $DiskUtilityContent);
		
   				$DiskUtilityContentrowOne = filter(explode(" ", $DiskUtilityContent[0]));
   				$DiskUtilityContentrowTwo = filter(explode(" ", $DiskUtilityContent[1]));
   				$DiskUtilityContentrowThree = filter(explode(" ", $DiskUtilityContent[2]));
   				$DiskUtilityContentrowFour = filter(explode(" ", $DiskUtilityContent[3]));
   				$DiskUtilityContentrowFive = filter(explode(" ", $DiskUtilityContent[4]));
   				$DiskUtilityContentrowSix = filter(explode(" ", $DiskUtilityContent[5]));
   				$DiskUtilityContentrowSeven = filter(explode(" ", $DiskUtilityContent[6]));
				
   		   echo "</td>
   		   </tr>
   <table width='100%' cellspacing='2' cellpadding='4' style='border:solid thin #999999; background:#fff; margin-bottom:15px;'>
   			<tbody><tr style='background:#083b82; height:24px; '>
   				<td valign='top' colspan='2' style='color:#ffffff; font-size:12px;'>Networks</td>
   			</tr>";
   			exec("lspci | grep Ethernet | wc -l ", $datanode03809);
   			$datacount = (int)$datanode03809[0];
   			$rowInstructor = 1;
   			exec("ip link | grep UP", $datanode91);
   			//exec("cat /var/www/html/universus/filetesting0380/run", $datanode91);
   			$showdatatmp91 = htmlspecialchars(implode('\n', $datanode91));
   			$showdatatmp91 = explode(": eth", $showdatatmp91);
   			array_shift($datanode91);
   			$ethernetRowCount91 = array();
   
   			foreach ($datanode91 as $value191) {
   				$ethernetRowCount91[] = substr_count($value191,",UP,");
   			}
   			$mycounter = 0;
   			foreach ($ethernetRowCount91 as $value) {
   				if ($value >= 1) {
   					echo "<tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top' class='naming'>Eth$mycounter Status</td>
   				<td valign='top'><img width='16' align='absmiddle' src='img/green.png'> up</td>
   		   </tr>";
   				}
   				else{
   					echo "<tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top' class='naming'>Eth$mycounter Status</td>
   				<td valign='top'><img width='16' align='absmiddle' src='img/red.png'> up</td>
   		   </tr>";
   				}
   				$mycounter++;
   			}
   		echo "</tbody></table>
   		
   	</td>
   	<td valign='top'  align='left' valign='top'>";
			$i = 0;
			?>
			<TABLE width="100%" cellspacing="3" cellpadding="4" style='border:solid thin #999999; background:#fff; margin-bottom:15px;'>
   		    <tr style="background-color:#083b82; height:24px;">
   				<td valign='top'  style='color:#ffffff; font-size:12px; width:100% !important' colspan='8'>Disk Utility</td>
   			</tr>
		     <tr style='font-size:12px;'>
				<?for($i=0;$i<=count($DiskUtilityContentrowOne);$i++){?>
					<td valign='top' class='naming'><?=$DiskUtilityContentrowOne[$i]?></td>
				<?}?>
			 </tr>
			 <tr style='font-size:12px;'>
				<?for($i=0;$i<=count($DiskUtilityContentrowTwo);$i++){?>
					<td valign='top' class='naming'><?=$DiskUtilityContentrowTwo[$i]?></td>
				<?}?>
			 </tr>
			 <tr style='font-size:12px;'>
				<?for($i=0;$i<=count($DiskUtilityContentrowThree);$i++){?>
					<td valign='top' class='naming'><?=$DiskUtilityContentrowThree[$i]?></td>
				<?}?>
			 </tr>
			 <tr style='font-size:12px;'>
				<?for($i=0;$i<=count($DiskUtilityContentrowFour);$i++){?>
					<td valign='top' class='naming'><?=$DiskUtilityContentrowFour[$i]?></td>
				<?}?>
			 </tr>
			 <tr style='font-size:12px;'>
				<?for($i=0;$i<=count($DiskUtilityContentrowFive);$i++){?>
					<td valign='top' class='naming'><?=$DiskUtilityContentrowFive[$i]?></td>
				<?}?>
			 <tr style='font-size:12px;'>
				<?for($i=0;$i<=count($DiskUtilityContentrowSix);$i++){?>
					<td valign='top' class='naming'><?=$DiskUtilityContentrowSix[$i]?></td>
				<?}?>
			 <tr style='font-size:12px;'>
				<?for($i=0;$i<=count($DiskUtilityContentrowSeven);$i++){?>
					<td valign='top' class='naming'><?=$DiskUtilityContentrowFive[$i]?></td>
				<?}?>
			 </tr>

			 </TABLE>
			 
			
<? 
/* Changes Made for Disk Utility Record View on :: 29-08-2023 
##############################################################
End
*/

echo "</td>
   
   </tr>
   
   <tr>
   	<td valign='top'  align='left' valign='top'>
   		
   		<TABLE width=\"100%\" cellspacing=2 cellpadding=4 style='border:solid thin #999999; background:#fff; margin-bottom:15px;'>
   			<tr style=\"background:#083b82; height:24px; \">
   				<td valign='top'  style='color:#ffffff; font-size:12px;' colspan='2'>Server Status</td>
   			</tr>
   			<tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top'  class='naming'>Asterisk</td>
   				<td valign='top' >";
   				echo $asteriskstatus;
   		   echo "</td>
   		   </tr>
   		   <tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top'  class='naming'>Mysql</td>
   				<td valign='top' >";
   				/*$filename="/tmp/mysql.txt";
   				$filename="/var/www/html/tmp/mysql.txt";
   				if(file_exists($filename))
   				{
   					$file=fopen($filename,'r') or die("errorss".$filename);
   					$content=fread($file,filesize($filename));
   					$intpos=strpos($content,"is running...");
   					if (0 == filesize($filename))
   					{
   						echo "Not available.";
   					}
   					else {
   					if(is_int($intpos) && !empty($content)){ echo $green." OK"; }else { 
   					
   					echo $red." Not running"; 
   					
   					}
   					}
   					
   				}*/
   				 echo $green." OK";
   				
   		   echo "</td>
   		   </tr>
   		   <tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top'  class='naming'>Web Server</td>
   				<td valign='top' >";
   				$filename="/tmp/webserver.txt";
   				$filename="/var/www/html/tmp/webserver.txt";
   				if(file_exists($filename))
   				{
   					$file=fopen($filename,'r');
   					$content=fread($file,filesize($filename));
   					$intpos=strpos($content,"is running...");
   					if (0 == filesize($filename))
   					{
   						echo "Not available.";
   					}
   					else {
   					if(is_int($intpos)){ echo $green." OK"; }else { 
   					
   					echo $red." Not running"; 
   					
   					}
   					}
   					
   				}
   				
   		   echo "</td>
   		   </tr>
   		   <tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top'  class='naming'>SSH Server</td>
   				<td valign='top' >";
   				$filename="/tmp/sshserver.txt";
   				$filename="/var/www/html/tmp/sshd.txt";
   				if(file_exists($filename))
   				{
   					$file=fopen($filename,'r') ;
   					$content=fread($file,filesize($filename));
   					$intpos=strpos($content,"is running...");
   					
   					if (0 == filesize($filename))
   					{
   						echo "No PRI available.";
   					}
   					else {
   					if(is_int($intpos)){ echo $green." OK"; }else { 
   					
   					echo $red." Not running"; 
   					
   					}
   					}
   					
   				}
   				
   		   echo "</td>
   		   </tr>
   		   
   		</TABLE>
   		
   	</td>
   	<td valign='top'  align='left' valign='top'>
   		
   		<TABLE width=\"100%\" cellspacing=2 cellpadding=4 style='border:solid thin #999999; background:#fff; margin-bottom:15px;'>
   			<tr style=\"background:#083b82; height:24px; \">
   				<td valign='top'  style='color:#ffffff; font-size:12px;' colspan='2'>Asterisk</td>
   			</tr>
   			<tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top'  class='naming'>Total Active Channels</td>
   				<td valign='top' >";
   				$filename="/tmp/channels.txt";
   				$filename="/var/www/html/tmp/channels.txt";
   				if(file_exists($filename))
   				{
   					$file=fopen($filename,'r');
   					$content=fread($file,filesize($filename));
   					//$intpos=strpos($content,"is running...");
   					$contents=explode(' active channels',$content);
   					if (0 == filesize($filename))
   					{
   						echo "No PRI available.";
   					}
   					else {
   					if(!empty($content)){ echo $contents[0]; }
   					}
   					
   				}
   		   echo "</td>
   		   </tr>
   		   <tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top'  class='naming'>Total Active Calls</td>
   				<td valign='top' >";
   				$contentss=explode(' active calls',$contents[1]);
   				if(!empty($content)){ echo $contentss[0]; }
   		   echo "</td>
   		   </tr>
   		   <tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top'  class='naming'>Available Audio Codec</td>
   				<td valign='top' >
   				gsm,ulaw,alaw,g726,ilbc,g722
   				</td>
   		   </tr>
   		   <tr style='font-size:12px; background-color:#ffffff;'>
   				<td valign='top'  class='naming'>Available Video Codec</td>
   				<td valign='top' >
   				H261,H263,H263+,H264,MP3G4
   				</td>
   		   </tr>
   		   		   
   		</TABLE>
   		
   	</td>
   </tr>
   
   </table>
   
   <TABLE width=\"100%\" style=\"font-family:Verdana, Arial, Helvetica, sans-serif;\">
   <tr>
   		<td align='left' valign='top' colspan='2'>
   		
   		";
   		$arr=array("Idle           " => "green" , "Unavailable    " => "red" , "InUse          " => "yellow" , "Ringing        " => "blue" );
   		$arrr=array("Idle" => "green" , "Unavailable" => "red" , "InUse" => "yellow" , "Ringing" => "blue" );  
   		 
   		$numrows=mysqli_num_rows($res);
   echo	"<TABLE width=\"100%\" cellspacing=2 cellpadding=4 style='border:solid thin #999999; background:#fff; margin-bottom:15px;'>
   			<tr style=\"background:#083b82; height:24px; \">
   				<td valign='top'  style='color:#ffffff; font-size:12px;'>Extensions Live Status</td>
   				<td valign='top'  style='color:#ffffff; font-size:12px;'>
   				<div style='float:right;'>
   				<div class='mydiv box mydiv1'>Idle</div><div class='mydiv box' style='background:".$arrr['Idle'].";'>&nbsp;</div>
   				<div class='mydiv box mydiv1'>Unavailable</div><div class='mydiv box' style='background:".$arrr['Unavailable'].";'>&nbsp;</div>
   				<div class='mydiv box mydiv1'>InUse</div><div class='mydiv box' style='background:".$arrr['InUse'].";'>&nbsp;</div>
   				<div class='mydiv box mydiv1'>Ringing</div><div class='mydiv box' style='background:".$arrr['Ringing'].";'>&nbsp;</div>
   				</div>
   				</td>
   		   </tr>
   		   <tr style='font-size:12px; background-color:#ffffff;'>
   		   ";
   echo	   "<td valign='top' colspan='2'>";
   			$getExtensionDetail="select * from tbl_extensions where state!='' order by extension ";
   			$res=mysqli_query($link,$getExtensionDetail);
   			if ($res=="") {
   				include('dbconnect.php');
   				$res=mysqli_query($link,$getExtensionDetail);
   			}
   		   while($rest=mysqli_fetch_array($res))
   		   {
   		   $state=$rest['state'];
   		   //echo strlen($state);
   echo	   "<div class='naming mydiv'>".$rest['extension']."</div>
   			<div class='mydiv box' style='background:".$arrr[$state].";'>&nbsp;</div>";
   		   }
   echo	   "</td></tr>
   		</TABLE>	
   		
   	</td>
   </tr>
   </table>
   </div>
   
   
   </center>\n";
   
   echo "</TABLE></center></div>\n";
   
   ?>

<script src="jquery-latest.js"></script>
<script>

setTimeout(function(){
   window.location.reload(1);
}, 60000);

</script>